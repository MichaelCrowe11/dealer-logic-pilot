#!/bin/bash
cd /opt/dealer-logic
docker-compose logs -f
