#!/bin/bash

echo "Setting up Dealer Logic on server..."

# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install Docker and Docker Compose if not present
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
fi

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install nginx
sudo apt-get install -y nginx

# Install certbot for SSL
sudo apt-get install -y certbot python3-certbot-nginx

# Create application directory
sudo mkdir -p /opt/dealer-logic
sudo chown $USER:$USER /opt/dealer-logic

# Copy files to application directory
cp -r * /opt/dealer-logic/
cd /opt/dealer-logic

# Install dependencies
npm install --production

# Start services with Docker Compose
docker-compose up -d

# Setup nginx configuration
sudo tee /etc/nginx/sites-available/dealerlogic.io << 'NGINX'
server {
    listen 80;
    server_name dealerlogic.io www.dealerlogic.io api.dealerlogic.io hooks.dealerlogic.io;
    return 301 https://$server_name$request_uri;
}
NGINX

sudo ln -sf /etc/nginx/sites-available/dealerlogic.io /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# Obtain SSL certificates
sudo certbot --nginx -d dealerlogic.io -d www.dealerlogic.io -d api.dealerlogic.io -d hooks.dealerlogic.io --non-interactive --agree-tos --email alerts@dealerlogic.io

echo "✅ Setup complete!"
echo "Services running:"
docker-compose ps
